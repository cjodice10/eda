# eda
This is a package that is used to help with exploratory data analysis (EDA) when the dependent variable (DV) is either binary or a frequency type.